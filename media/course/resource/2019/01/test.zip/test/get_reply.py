import os
import json
import codecs

BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # 文件夹目录
TEXT_DIR = os.path.join(BASE_DIR, 'text')
REPLY_DIR = os.path.join(BASE_DIR, 'reply')
  # 得到文件夹下的所有文件名

def get_reply(filename):
    with open(os.path.join(TEXT_DIR, filename), 'r', encoding='UTF-8') as f:
        for line in f:
            dict = json.loads(line)
            save_reply(os.path.join(REPLY_DIR, filename),dict['reply'])

def save_reply(filename,data):
    if not os.path.exists(REPLY_DIR):
        os.makedirs(REPLY_DIR)
    try:
        f = codecs.open(os.path.join(REPLY_DIR,filename),'a', encoding='utf-8')
        f.writelines(data + '\n')
    except FileNotFoundError as e:
        print('写入文件失败')


if __name__ == "__main__":
    for file in os.listdir(TEXT_DIR):
        get_reply(file)

    
